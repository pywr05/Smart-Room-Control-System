
#include <DHT.h>
#include <Keypad.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>


// LCD Setup
LiquidCrystal_I2C lcd(0x27, 16, 2);

// DHT Sensor Setup 
#define DHTPIN 2
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// Pin Setup
const int ldrPin = A0;
const int ledPin = 8;
const int fanPin = 9;

// Keypad Setup
const byte ROWS = 4;
const byte COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {3, 4, 5, 6};
byte colPins[COLS] = {10, 11, 12, 13};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// System States
bool autoMode = true;
bool manualLight = false;
bool manualFan = false;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(fanPin, OUTPUT);
  Serial.begin(9600);
  dht.begin();

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Smart Room Ctrl");
  delay(2000);
  lcd.clear();

  Serial.println("System Initialized");
}

void loop() {
  char key = keypad.getKey();

  // Mode switching
  if (key == 'C') {
    autoMode = true;
    Serial.println("AUTO mode");
    lcd.clear();
  } else if (key == 'D') {
    autoMode = false;
    Serial.println("MANUAL mode");
    lcd.clear();
  }

  lcd.setCursor(0, 0);
  lcd.print("Mode: ");
  lcd.print(autoMode ? "AUTO   " : "MANUAL ");
if (autoMode) {
    // AUTO Mode
    int ldrVal = analogRead(ldrPin);
    digitalWrite(ledPin, ldrVal < 500 ? HIGH : LOW);

    float temp = dht.readTemperature();
    float hum = dht.readHumidity();

    digitalWrite(fanPin, temp > 30 ? HIGH : LOW);

    // Print to Serial
    Serial.print("Temp: ");
    Serial.print(temp);
    Serial.print(" °C, Humidity: ");
    Serial.print(hum);
    Serial.println(" %");

    // Clean LCD line before printing
    lcd.setCursor(0, 1);
    lcd.print("                ");  
    lcd.setCursor(0, 1);
    lcd.print("T:");
    lcd.print(temp, 1);
    lcd.print("C H:");
    lcd.print(hum, 0);
    lcd.print("%");

  } else {
    // MANUAL Mode
    if (key == 'A') {
      manualLight = !manualLight;
      Serial.println(manualLight ? "Light ON" : "Light OFF");
    }
    if (key == 'B') {
      manualFan = !manualFan;
      Serial.println(manualFan ? "Fan ON" : "Fan OFF");
    }

    digitalWrite(ledPin, manualLight);
    digitalWrite(fanPin, manualFan ? HIGH : LOW);

  
    lcd.setCursor(0, 1);
    lcd.print("                ");
    lcd.setCursor(0, 1);
    lcd.print("L:");
    lcd.print(manualLight ? "ON " : "OFF");
    lcd.print(" F:");
    lcd.print(manualFan ? "ON " : "OFF");
  }

  delay(200);
}